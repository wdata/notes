<a name="searchBar"></a>

## searchBar(selector)
searchbar 搜索框，主要实现搜索框组件一些显隐逻辑

**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| selector | <code>string</code> | searchbar的selector |

**Example**  
```js
weui.searchBar('#searchBar');
```
