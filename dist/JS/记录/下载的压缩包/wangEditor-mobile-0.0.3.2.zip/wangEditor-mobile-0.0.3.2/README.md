## wangEditor-mobile 真正适用于手指触摸的富文本编辑器！

**wangEditor-mobile** 是一款专门为手机、平板操作而设计、开发的富文本编辑器。它和传统编辑器相比，应该适用于小屏幕、手指触摸操作。

<img src="http://box.kancloud.cn/2015-12-16_5671787d60766.png" width="300" style="width:300px">

-------------------

**wangEditor-mobile** 支持的系统和浏览器：

- iOS：safari、chrome、UC、QQ浏览器、微信；
- 安卓：chrome、UC、QQ浏览器、微信；

-------------------

扫描二维码预览demo

![二维码](http://images2015.cnblogs.com/blog/138012/201511/138012-20151123204103952-2028180164.png)

官网：[wangEditor.github.io/m](http://wangeditor.github.io/m/)

文档：[www.kancloud.cn/wangfupeng/wangeditormobile/94402](http://www.kancloud.cn/wangfupeng/wangeditormobile/94402)