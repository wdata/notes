// 自定义alert
window.___E_mod(function (E, $) {


});