// editor API 对外开放的接口
window.___E_mod(function (E, $) {

	

});