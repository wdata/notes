<?php
/**
 * Created by IntelliJ IDEA.
 * User: FollowWinter
 * Date: 23/12/2016
 * Time: 14:46
 */
echo json_encode([
    'code' => '100',
    'summary' => 'success',
    'data' => [
        'url' => '/service/21.png'
    ]
]);